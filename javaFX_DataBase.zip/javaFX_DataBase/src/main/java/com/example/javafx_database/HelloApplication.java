package com.example.javafx_database;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;

public class HelloApplication extends Application {

    private static String URL = "jdbc:mysql://localhost:3306/products";
    private static String USER = "root";
    private static String PASS = null;
    private static String INSERT_QUERY = "insert into product (name, price) values (?, ?)";
    private static String SELECT_QUERY = "select * from product";


    @Override
    public void start(Stage stage) throws IOException {
        Label nameLabel = new Label("Eneter name: ");
        Label priceLabel = new Label("Enter price: ");
        TextField nameTextField = new TextField();
        TextField priceTextField = new TextField();
        Button addButt = new Button("Add To Database");
        Button pieChartButt = new Button("Show PieChart");

        GridPane gridPane = new GridPane();
        gridPane.addColumn(0, nameLabel, nameTextField);
        gridPane.addColumn(0, priceLabel, priceTextField);
        gridPane.addColumn(0, addButt, pieChartButt);
        nameTextField.setMaxWidth(150);
        priceTextField.setMaxWidth(150);
        addButt.setTranslateY(20);
        pieChartButt.setTranslateY(40);

        addButt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    Connection connection = DriverManager.getConnection(URL, USER, PASS);
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement.executeQuery(SELECT_QUERY);

                    String name = nameTextField.getText();
                    double price = Double.parseDouble(priceTextField.getText());

                    Product product = new Product(name, price);

                    PreparedStatement preparedStatement = connection.prepareStatement(INSERT_QUERY);
                    preparedStatement.setString(1, product.getName());
                    preparedStatement.setDouble(2, product.getPrice());
                    preparedStatement.execute();

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });


        pieChartButt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    Connection connection = DriverManager.getConnection(URL, USER, PASS);
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement.executeQuery(SELECT_QUERY);



                    LocalDate localDate = LocalDate.now();
                    ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
                    while(resultSet.next()){
                        String name = resultSet.getString("name");
                        String nameAndDate = name + ' ' + localDate.toString();
                        double price = resultSet.getDouble("price");
                        pieData.add(new PieChart.Data(nameAndDate, price));
                    }
                    PieChart pieChart = new PieChart(pieData);
                    gridPane.addColumn(0, pieChart);

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Scene scene = new Scene(gridPane, 600, 600);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}