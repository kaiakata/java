﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Access__modifiers_constructors
{
    class Book
    {
        public string title;
        public string author;
        public int page;
        public Book(string aTitle,string aAuthor,int aPage)
        { 
            title = aTitle; 
            author = aAuthor;
            page = aPage;
            
            
        }

    }
}
