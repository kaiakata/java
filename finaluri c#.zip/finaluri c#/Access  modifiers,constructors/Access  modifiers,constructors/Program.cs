﻿using Access__modifiers_constructors;
using System;

namespace modifiers
{
    class program
    {
          static void Main(string[] args) 
        {   
            Book book = new Book("karibis zgvis mekobreebi", "Jack Sparrow",800);
            



            Console.WriteLine(book.title);
        }
    }
}




// modifaers 
// privet int a = 0;
//protected int b = 1;
//public int c = 3;