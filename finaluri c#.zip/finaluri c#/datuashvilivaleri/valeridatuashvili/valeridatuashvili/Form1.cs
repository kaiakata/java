namespace valeridatuashvili
{
    public partial class Form1 : Form
    {
        public static string barcode ="";
        public static string quantity="";
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1 = Form1.barcode;
            textBox5 = quantity;
            Form2 form2 = new Form2();
            form2.Show();
        }
    }
}