﻿using System;
namespace interfaces
{
    class program
    {
        static void Main(string[] args) 
        {
                
            Rabit rabit = new Rabit();
            Hawk hawk = new Hawk();
            Fish fish = new Fish();
            rabit.Flee();
            hawk.hunter();
            fish.hunter();
            fish.Flee();


        }
    }
    interface IPray 
    {
        void Flee();
    }
    interface IPredator
    {
        void hunter();
    }
    class Rabit : IPray
    {
        public void Flee()
        {
            Console.WriteLine("rubbit run from hunter");
        }
    }
    class Hawk : IPredator
    {
        public void hunter()
        {
            Console.WriteLine("Hawk runs to cach pray");
        }
    }
    class Fish : IPredator , IPray
    {
        public void hunter() 
        {
            Console.WriteLine("Fish search for little fish");
        }
        public void Flee()
        {
            Console.WriteLine("Fish runs from big fish");
        }
    }
}