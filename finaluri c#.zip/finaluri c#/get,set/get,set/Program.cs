﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GeterAndSeter
{
    //                                                  Get Set methods
    //class GETANDSET {
    //    static void Main(string[] args)
    //    {
    //        Car car = new Car();
    //        car.nameofcar = "mercedes";
    //        Console.WriteLine(car.nameofcar);
    //    }

    //    class Car
    //    {
    //        private string NameOfCar;
    //        public string nameofcar
    //        {
    //            get
    //            {
    //                return NameOfCar;
    //            }
    //            set
    //            {
    //                NameOfCar = value;
    //            }
    //        }
    //    }
    //}


}
