﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes_and_inheritance
{
    class Vehicle
    {
        public int speed=0;
        public void go()
        {
            Console.WriteLine("this vehicle is moving!");
        }

    }

    class Car : Vehicle
    {
        public int wheel = 4;
        
    }
     class Bicycl : Vehicle
    {
        public int wheel = 2;
        
    }
    class Boat: Vehicle
    {
        public int wheel = 0;

    }
    class Plain: Vehicle
    {
        public int wheel = 0;

    }
}

