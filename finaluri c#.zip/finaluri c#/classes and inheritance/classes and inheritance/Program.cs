﻿using classes_and_inheritance;
using System;
using System.IO.Pipes;

namespace classes{

    class program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            Boat boat = new Boat();
            Bicycl bicycl = new Bicycl();
            Plain plain = new Plain();
            Console.WriteLine(car.speed);
            Console.WriteLine(car.wheel);
            car.go();
            Console.WriteLine(boat.speed);
            Console.WriteLine(boat.wheel);
            boat.go();
            Console.WriteLine(bicycl.speed);
            Console.WriteLine(bicycl.wheel);
            bicycl.go();
            Console.WriteLine(plain.speed);
            Console.WriteLine(plain.wheel);
            plain.go();
        }
    }
   

}